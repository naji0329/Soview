import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';


const ChartGraph = ({  }) => {
  return (
    <Fragment>

    </Fragment>
  );
};

ChartPrChartGraphice.propTypes = {
};

export default connect(null, {  })(ChartGraph);
